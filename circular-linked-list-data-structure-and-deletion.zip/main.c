#include<stdio.h>
#include<stdlib.h>
 void insertion();
 void display();
 void deletion();
 struct node
 {
     int data;
     struct node *next;
     
 }
 *newnode,*temp,*head,*prev;
 void main()
 
 {
     insertion();
     display();
     deletion();
     display();
 }
 void insertion()
 {
     int choice=1;
     while(choice==1)
     {
     newnode=malloc(sizeof(struct node));
     printf("enter the data ");
     scanf("%d",&newnode->data);
     
     newnode->next=0;
     if (head==0)
     {
        head=newnode;
        newnode->next=head;
     }
     else
  {
      temp=head;
      while(temp->next!=head)
      {
          temp=temp->next;
      }
          temp->next=newnode;
          newnode->next=head;
      
  }
  
     
     printf("Enter your choice");
     scanf("%d",&choice);
     }
 }
 void display()
 {
     temp=head;
     while(temp->next!=head)
     {
         printf("%d ",temp->data);
         temp=temp->next;
     }
     printf("%d ",temp->data);
 }

void deletion()
{
    int element;
    printf("\nEnter the element to be deleted ");
    scanf("%d",&element);
    temp=head;
    while(temp->data!=element)
    {
        prev=temp;
        temp=temp->next;
        
    }
    prev->next=temp->next;
    free(temp);
}
