#include <stdio.h>
#include <stdlib.h>
struct node 
{
    int data;
    struct node *left;
    struct node *right;
}*newnode,*root,*temp;
void display(struct node*root);
void insert();
void search(struct node *newnode,struct node *root);
void delete();
int main()
{
insert();
display(root);
delete();
}
void insert()
{
    int choice=1;
    while(choice==1)
    {
        newnode=malloc(sizeof(struct node));
        newnode->left=0;
        newnode->right=0;
        printf("Enter the data");
        scanf("%d",&newnode->data);
        if(root==0)
        {
            root=newnode;
        }
        else
        {
            search(newnode,root);
        }
        printf("Choice ");
        scanf("%d",&choice);
    }
}
void search(struct node *newnode,struct node *root)
{
    if((newnode->data)<(root->data)&&root->left==0)
    {
        root->left=newnode;
    }
    if((newnode->data)>(root->data)&&root->right==0)
    {
        root->right=newnode;
    }
    if((newnode->data)<(root->data)&&root->left!=0)
    {
        search(newnode,root->left);
    }
    if((newnode->data)>(root->data)&&root->right!=0)
    {
        search(newnode,root->right);
    }
}
void display(struct node *root)
{
    if(root==0)
    {
        return;
    }
    else
    {
        display(root->left);
        printf("%d ",root->data);
        display(root->right);
}
}
void delete()
{   int element;
    printf("Enter the element to be deleted ");
    scanf("%d ",&element);
    temp=root;
    while(temp->data!=element)
    {
        if(temp->data)
    }
    if (temp->left==0&&temp->right==0)
    {
    
        free(root);
    }
    
}
