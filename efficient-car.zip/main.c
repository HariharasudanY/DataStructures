#include <stdio.h>
#include<stdlib.h>
struct cars{
    int kml,cl,sp,mr,mcm;
}A,B;
int main()
{
    int x,y;
    scanf("%d",&A.kml);
   scanf("%d",&A.cl);
   scanf("%d",&A.sp);
   scanf("%d",&A.mr);
   scanf("%d",&A.mcm);
   scanf("%d",&B.kml);
   scanf("%d",&B.cl);
   scanf("%d",&B.sp);
   scanf("%d",&B.mr);
   scanf("%d",&B.mcm);
  x= A.sp + (A.mcm* 60)+((A.mr * A.cl * 60)/A.kml);
  y= B.sp + (B.mcm* 60)+((B.mr * B.cl * 60)/B.kml);
   if(x>y)
   printf("diesel");
   else
   printf("petrol");
    return 0;
}

