#include <stdio.h>
#include<stdlib.h>
void insertion();
void display();
struct node
{
    int data;
    struct node *next;
}
*newnode,*head,*temp;
int main()
{ 
    insertion();
    display();
    
}
    
void insertion()
{
    int choice=1,lengths=1;
    while (choice==1)
    {
        newnode= malloc(sizeof(struct node));
        printf("enter the data");
        scanf("%d",&newnode->data);
        newnode->next=0;
        if (head==0)
        {
            head=newnode;
        }
        else
        {
            temp=head;
            while(temp->next!=0)
            {
                temp=temp->next;
            }
            temp->next=newnode;
            
      lengths++;
        
    }

printf("enter your choice");
scanf("%d",&choice);
}
printf(" length is %d\n",lengths);
    if(lengths%2==0)
        {
            printf("node is even\n");
        }
        else
        {
            printf("node is odd\n");
        }
}
void display()
 { 
     printf("The elements are\n");
     temp=head;
     while(temp->next!=0)
     {
         printf("%d\n",temp->data);
         temp=temp->next;
     }
     printf("%d\n",temp->data);
 }

