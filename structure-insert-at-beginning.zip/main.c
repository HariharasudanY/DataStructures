#include<stdio.h>
#include<stdlib.h>
 void insertAtEnd();
 void display();
 
 struct node
 {
     int data;
     struct node *next;
     
 }
 *newnode,*temp,*head;
 void main()
 
 {
     insertAtEnd();
     display();
 }
 void insertAtEnd()
 {
     int choice=1;
     while(choice==1)
     {
     newnode=malloc(sizeof(struct node));
     printf("enter the data");
     scanf("%d",&newnode->data);
     
     newnode->next=0;
     if (head==0)
     {
        head=newnode;
     }
     else
     {
         newnode->next=head;
         head=newnode;
     }
     printf("enter the choice");
     scanf("%d",&choice);
     }
 }
 void display()
 {
     temp=head;
     while(temp->next!=0)
     {
         printf("%d",temp->data);
         temp=temp->next;
     }
     printf("%d",temp->data);
 }
